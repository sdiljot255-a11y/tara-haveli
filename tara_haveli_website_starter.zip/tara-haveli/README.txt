TARA HAVELI WEBSITE — FREE STARTER

FILES
- index.html: the complete responsive website.

BEFORE PUBLISHING
1. Ask your father to check and approve all text, photos, contact details and claims.
2. Open index.html in a text editor.
3. Find ADD_HOTEL_NUMBER_HERE and replace it with the hotel's WhatsApp number:
   country code 91 + 10-digit mobile number, digits only.
   Example format: 919876543210 (example only, do not use this number).
4. Replace the photo placeholder areas with real hotel photos. The comments in index.html mark the places.
5. Update the location with the full verified address and PIN code if your father approves.
6. Add actual room details, restaurant timings, prices and party packages only after your father confirms them.

FREE PUBLISHING WITH GITHUB PAGES
1. Sign in to the GitHub account managed by your parent.
2. Create a new public repository named: tara-haveli
3. Upload index.html to the repository's main/root folder.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. The address will look like:
   https://YOUR-GITHUB-USERNAME.github.io/tara-haveli/

NOTES
- GitHub Pages hosting is free for a public repository.
- A custom .com domain is optional and costs money; you do not need one to start.
- This is an enquiry website, not a live hotel inventory/booking engine.
- The form opens a pre-filled WhatsApp message. It does not automatically confirm bookings.
- Do not collect or store customers' sensitive personal or payment information.
- Have your father manage the website account, customer enquiries, and any future paid services.
